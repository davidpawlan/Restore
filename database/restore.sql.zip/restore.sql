-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 16, 2020 at 10:58 AM
-- Server version: 5.7.21
-- PHP Version: 7.2.16-1+ubuntu14.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restore`
--

-- --------------------------------------------------------

--
-- Table structure for table `behaviors`
--

CREATE TABLE `behaviors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `behaviors`
--

INSERT INTO `behaviors` (`id`, `name`, `short_name`, `created_at`, `updated_at`) VALUES
(1, 'Insubordination', 'IN', '2019-07-22 07:20:43', NULL),
(2, 'Inappropriate Language', 'IL', '2019-07-22 07:20:43', NULL),
(3, 'Inappropriate Contact', 'IC', '2019-07-22 07:20:43', NULL),
(4, 'Fighting', 'FI', '2019-07-22 07:20:43', NULL),
(5, 'Classroom Disruption', 'CD', '2019-07-22 07:20:43', NULL),
(6, 'Property Infraction', 'PI', '2019-07-22 07:20:43', NULL),
(7, 'Bullying', 'BU', '2019-07-22 07:20:43', NULL),
(8, 'Inappropriate Attitude', 'IA', '2019-07-22 07:20:43', NULL),
(9, 'Tardy/Truant', 'TT', '2019-07-22 07:20:43', NULL),
(10, 'Other', 'OT', '2019-07-22 07:20:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Kindergarten', '2019-07-22 07:20:43', NULL),
(2, '1st grade', '2019-07-22 07:20:44', NULL),
(3, '2nd grade', '2019-07-22 07:20:44', NULL),
(4, '3rd grade', '2019-07-22 07:20:44', NULL),
(5, '4th grade', '2019-07-22 07:20:44', NULL),
(6, '5th grade', '2019-07-22 07:20:44', NULL),
(7, '6th grade', '2019-07-22 07:20:44', NULL),
(8, '7th grade', '2019-07-22 07:20:44', NULL),
(9, '8th grade', '2019-07-22 07:20:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `grade_rosters`
--

CREATE TABLE `grade_rosters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'Id of users table',
  `grade_id` int(11) NOT NULL COMMENT 'Id of grades table',
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1=>Active, 0=>Inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `interventions`
--

CREATE TABLE `interventions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `interventions`
--

INSERT INTO `interventions` (`id`, `name`, `short_name`, `created_at`, `updated_at`) VALUES
(1, 'Restorative Practice Only', 'RPO', '2019-07-22 07:20:44', NULL),
(2, 'Lunch Detention', 'LD', '2019-07-22 07:20:44', NULL),
(3, 'After School Detention', 'ASD', '2019-07-22 07:20:44', NULL),
(4, 'Internal Suspension', 'IS', '2019-07-22 07:20:44', NULL),
(5, 'External Suspension', 'ES', '2019-07-22 07:20:44', NULL),
(6, 'Other', 'OT', '2019-07-22 07:20:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`, `short_name`, `created_at`, `updated_at`) VALUES
(1, 'Classroom', 'CL', '2019-07-22 07:20:44', NULL),
(2, 'Playground', 'PL', '2019-07-22 07:20:44', NULL),
(3, 'Cafeteria', 'CA', '2019-07-22 07:20:44', NULL),
(4, 'Gym', 'GY', '2019-07-22 07:20:45', NULL),
(5, 'Hallway', 'HA', '2019-07-22 07:20:45', NULL),
(6, 'Common Area', 'COA', '2019-07-22 07:20:45', NULL),
(7, 'Bathroom', 'BA', '2019-07-22 07:20:45', NULL),
(8, 'Library', 'LI', '2019-07-22 07:20:45', NULL),
(9, 'Bus', 'BU', '2019-07-22 07:20:45', NULL),
(10, 'Other', 'OT', '2019-07-22 07:20:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_07_04_11320_create_schools_table', 1),
(4, '2019_07_04_113241_create_grades_table', 1),
(5, '2019_07_04_113242_create_students_table', 1),
(6, '2019_07_04_113307_create_grade_rosters_table', 1),
(7, '2019_07_04_113516_create_behaviors_table', 1),
(8, '2019_07_04_113530_create_locations_table', 1),
(9, '2019_07_04_113600_create_interventions_table', 1),
(10, '2019_07_11_113321_create_reports_table', 1),
(11, '2017_03_06_023521_create_admins_table', 2),
(12, '2017_03_06_053834_create_admin_role_table', 2),
(13, '2018_03_06_023523_create_roles_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('vvvvvv@yopmail.com', 'ne3HBmFDRw0846', '2019-08-23 08:06:46');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'Id of users table',
  `student_id` int(11) NOT NULL COMMENT 'Id of students table',
  `grade_id` int(11) DEFAULT NULL,
  `gender` enum('M','F') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'M=>Male, F=>Female',
  `behaviour_id` int(11) NOT NULL COMMENT 'Id of behaviour table',
  `location_id` int(11) NOT NULL COMMENT 'Id of locations table',
  `intervention_id` int(11) NOT NULL COMMENT 'Id of interventions table',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `self_awareness` int(11) NOT NULL COMMENT '0=>Poor, 1->Avg 2=>optimal',
  `self_management` int(11) NOT NULL COMMENT '0=>Poor, 1->Avg 2=>optimal',
  `responsible_decision_making` int(11) NOT NULL COMMENT '0=>Poor, 1->Avg 2=>optimal',
  `relationship_skills` int(11) NOT NULL COMMENT '0=>Poor, 1->Avg 2=>optimal',
  `social_awareness` int(11) NOT NULL COMMENT '0=>Poor, 1->Avg 2=>optimal',
  `other_notes` longtext COLLATE utf8mb4_unicode_ci COMMENT '0=>Poor, 1->Avg 2=>optimal',
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1=>ACtive, 0=>Archieve',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'User''s Table Id',
  `principle_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Princile name for school',
  `plain_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Plain password etxt to show in admin',
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `user_id`, `principle_name`, `plain_password`, `profile_image`) VALUES
(3, 3, 'New School', '11111111', ''),
(4, 4, 'Mr Johan', '12345678', ''),
(5, 5, 'ddd', '12345678', '15664710105.jpg'),
(6, 6, 'ggd', '12345678', ''),
(7, 7, 'vvvvvv', '12345678', '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'Id of users table',
  `grade_id` int(11) NOT NULL COMMENT 'Id of grades table',
  `grade_roster_id` int(11) NOT NULL COMMENT 'Id of grade_roster table',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roll_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('M','F') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'M=>Male, F=>Female',
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '0=>Archieve, 1=>Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('A','S') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A=>Admin, S=>School',
  `profile_pic` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1=>Active, 0=>Deactivate',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `type`, `profile_pic`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Admin Heress', 'admin@gmail.com', '$2y$10$ze7jok.A8PK2O0n0qcbIb.TIW24bhS79P1LW/OrJ3J10tNzXFJbdi', 'A', '15653523979.png', '1', NULL, '2019-08-21 00:38:35'),
(3, 'test school open', 'test_school@yopmail.com', '$2y$10$ze7jok.A8PK2O0n0qcbIb.TIW24bhS79P1LW/OrJ3J10tNzXFJbdi', 'S', NULL, '1', '2019-07-25 05:21:54', '2019-07-31 07:32:31'),
(4, 'Next Generation School', 'nest@yopmail.com', '$2y$10$uaQnaFnrtTWvJHzV.cv3kupPZxgJpIPgqvJJ/n/.Ju.X7ZSTSrgca', 'S', NULL, '1', '2019-07-31 03:35:10', '2019-07-31 03:41:10'),
(5, 'ddd', 'dd@gmail.com', '$2y$10$XVl0Pg/jpTx7W41mvupakOhgrWrbCzgNLXMHQqwh2dWwjojNZoJqW', 'S', '15664710105.jpg', '1', '2019-08-21 06:16:14', '2019-08-22 05:20:10'),
(6, 'sdd', 'ddd@yopmail.com', '$2y$10$/9LVXiHqsfLXmEF.jLOQR.iyvWf6wiLGZRG3cZp.witwyTeNRuAZm', 'S', NULL, '1', '2019-08-21 23:32:00', NULL),
(7, 'vvvvvv', 'vvvvvv@yopmail.com', '$2y$10$t7Pm8ASx3OQgRoNSKDmXfepOel/s8nhJ6CDcIidYGR667ftA6.j2u', 'S', NULL, '1', '2019-08-23 08:06:10', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `behaviors`
--
ALTER TABLE `behaviors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grade_rosters`
--
ALTER TABLE `grade_rosters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interventions`
--
ALTER TABLE `interventions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_id_2` (`user_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `behaviors`
--
ALTER TABLE `behaviors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `grade_rosters`
--
ALTER TABLE `grade_rosters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `interventions`
--
ALTER TABLE `interventions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `schools`
--
ALTER TABLE `schools`
  ADD CONSTRAINT `schools_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
